package bg.softuni.exam.service;

public interface OrderService {
}
