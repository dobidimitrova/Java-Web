package bg.softuni.exam.entity.enums;

public enum CategoryNameEnum {
    Foundation,Powder,Bronzer,Mascara,Eyebrows,Brushes
}
